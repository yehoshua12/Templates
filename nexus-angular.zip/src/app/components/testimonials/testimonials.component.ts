import { Component } from '@angular/core';

@Component({
  selector: 'app-testimonials',
  standalone: true,
  templateUrl: './testimonials.component.html',
  styleUrls: ['./testimonials.component.scss'],
})
export class TestimonialsComponent {
  testimonials = [
    {
      text: 'Nexus redujo el tiempo de onboarding de clientes de 3 semanas a 4 días. Es increíble la diferencia que hace tener todo centralizado.',
      initials: 'AC', name: 'Ana Castillo', role: 'COO · Starkflow',
    },
    {
      text: 'Las automatizaciones de IA son lo que nos hizo decidir. Ahorramos 40 horas al mes en tareas administrativas. El ROI fue inmediato.',
      initials: 'MR', name: 'Miguel Reyes', role: 'CTO · Meridian Labs',
    },
    {
      text: 'El soporte es excepcional. Cada vez que tuve una duda me respondieron en menos de 2 horas. Se nota que el equipo realmente se preocupa.',
      initials: 'LV', name: 'Laura Vargas', role: 'Founder · VaultHQ',
    },
  ];
}
