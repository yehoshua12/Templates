import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';

export interface FaqItem {
  question: string;
  answer: string;
}

@Component({
  selector: 'app-faq',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.scss'],
})
export class FaqComponent {
  openIndex = signal<number | null>(null);

  faqs: FaqItem[] = [
    {
      question: '¿Necesito tarjeta de crédito para el plan gratuito?',
      answer: 'No. El plan Starter es completamente gratuito y no requiere datos de pago. Solo creas una cuenta con tu email y comienzas a usar Nexus de inmediato.',
    },
    {
      question: '¿Puedo cambiar de plan en cualquier momento?',
      answer: 'Sí. Puedes hacer upgrade o downgrade en cualquier momento desde tu panel. Los cambios se aplican al siguiente ciclo de facturación y te cobraremos o abonaremos la diferencia prorrateada.',
    },
    {
      question: '¿Dónde se almacenan mis datos?',
      answer: 'Todos los datos se almacenan en centros de datos AWS con certificación ISO 27001 en regiones de tu elección (US o EU). Ofrecemos cifrado en reposo y en tránsito con AES-256.',
    },
    {
      question: '¿Tienen soporte en español?',
      answer: 'Sí. Nuestro equipo de soporte opera en español e inglés, de lunes a viernes de 9am a 8pm (CDMX). Los planes Pro y Enterprise tienen acceso a soporte prioritario.',
    },
    {
      question: '¿Ofrecen descuentos para startups o ONGs?',
      answer: 'Sí. Contamos con un programa especial para startups aceleradas y organizaciones sin fines de lucro con hasta 60% de descuento. Escríbenos a founders@nexus.io.',
    },
  ];

  toggle(index: number): void {
    this.openIndex.set(this.openIndex() === index ? null : index);
  }

  isOpen(index: number): boolean {
    return this.openIndex() === index;
  }
}
