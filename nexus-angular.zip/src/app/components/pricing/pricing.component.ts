import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

export interface PricingPlan {
  tier: string;
  price: string | number;
  isCustom?: boolean;
  description: string;
  featured?: boolean;
  features: { text: string; included: boolean }[];
  cta: string;
  ctaStyle: 'primary' | 'ghost';
}

@Component({
  selector: 'app-pricing',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './pricing.component.html',
  styleUrls: ['./pricing.component.scss'],
})
export class PricingComponent {
  plans: PricingPlan[] = [
    {
      tier: 'Starter',
      price: 0,
      description: 'Para explorar y proyectos pequeños.',
      cta: 'Comenzar gratis',
      ctaStyle: 'ghost',
      features: [
        { text: 'Hasta 3 usuarios', included: true },
        { text: '5 workflows', included: true },
        { text: '1 GB almacenamiento', included: true },
        { text: 'IA automatización', included: false },
        { text: 'Soporte prioritario', included: false },
      ],
    },
    {
      tier: 'Pro',
      price: 49,
      description: 'Para equipos que quieren crecer rápido.',
      featured: true,
      cta: 'Empezar ahora',
      ctaStyle: 'primary',
      features: [
        { text: 'Hasta 25 usuarios', included: true },
        { text: 'Workflows ilimitados', included: true },
        { text: '50 GB almacenamiento', included: true },
        { text: 'IA automatización', included: true },
        { text: 'Soporte prioritario', included: false },
      ],
    },
    {
      tier: 'Enterprise',
      price: 'Custom',
      isCustom: true,
      description: 'Para organizaciones con necesidades avanzadas.',
      cta: 'Hablar con ventas',
      ctaStyle: 'ghost',
      features: [
        { text: 'Usuarios ilimitados', included: true },
        { text: 'Workflows ilimitados', included: true },
        { text: 'Almacenamiento ilimitado', included: true },
        { text: 'IA automatización', included: true },
        { text: 'Soporte 24/7 dedicado', included: true },
      ],
    },
  ];
}
