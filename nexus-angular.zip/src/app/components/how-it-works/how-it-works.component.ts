import { Component } from '@angular/core';

@Component({
  selector: 'app-how-it-works',
  standalone: true,
  templateUrl: './how-it-works.component.html',
  styleUrls: ['./how-it-works.component.scss'],
})
export class HowItWorksComponent {
  steps = [
    { num: '01', title: 'Crea tu cuenta', desc: 'Regístrate con tu email o Google. Configura tu espacio de trabajo en segundos.' },
    { num: '02', title: 'Conecta tus herramientas', desc: 'Importa tus datos desde las apps que ya usas. Sin CSV, sin migraciones manuales.' },
    { num: '03', title: 'Automatiza y escala', desc: 'Activa workflows de IA y observa cómo tu equipo se enfoca en lo que importa.' },
  ];

  integrations = [
    { icon: 'ti-brand-slack',  name: 'Slack',    color: '#4A154B' },
    { icon: 'ti-brand-stripe', name: 'Stripe',   color: '#635BFF' },
    { icon: 'ti-brand-google', name: 'Google',   color: '#4285F4' },
    { icon: 'ti-brand-github', name: 'GitHub',   color: '#24292E' },
    { icon: 'ti-brand-notion', name: 'Notion',   color: '#24292E' },
  ];

  activeInt: string | null = null;
  select(name: string) { this.activeInt = name; }
}
