import { Component } from '@angular/core';

interface Stat {
  value: string;
  label: string;
}

@Component({
  selector: 'app-hero',
  standalone: true,
  templateUrl: './hero.component.html',
  styleUrls: ['./hero.component.scss'],
})
export class HeroComponent {
  stats: Stat[] = [
    { value: '+12k', label: 'Equipos activos' },
    { value: '99.9%', label: 'Uptime garantizado' },
    { value: '4.9/5', label: 'Satisfacción' },
  ];

  chartBars = [40, 55, 45, 70, 60, 80, 72, 100];
}
