import { Component } from '@angular/core';

export interface Feature {
  icon: string;
  title: string;
  description: string;
}

@Component({
  selector: 'app-features',
  standalone: true,
  templateUrl: './features.component.html',
  styleUrls: ['./features.component.scss'],
})
export class FeaturesComponent {
  features: Feature[] = [
    {
      icon: 'ti-chart-dots-3',
      title: 'Analytics en tiempo real',
      description: 'Dashboards personalizables con datos actualizados al instante. Visualiza el rendimiento de cada área de tu negocio.',
    },
    {
      icon: 'ti-robot',
      title: 'Automatización con IA',
      description: 'Delega tareas repetitivas a nuestro motor de inteligencia artificial. Ahorra hasta 12 horas semanales por persona.',
    },
    {
      icon: 'ti-plug-connected',
      title: '+200 integraciones',
      description: 'Conecta con Slack, HubSpot, Stripe, Notion y más. Configura webhooks personalizados en segundos.',
    },
    {
      icon: 'ti-users-group',
      title: 'Gestión de equipos',
      description: 'Roles, permisos y espacios de trabajo individuales. Colabora sin fricción entre departamentos.',
    },
    {
      icon: 'ti-shield-lock',
      title: 'Seguridad enterprise',
      description: 'Cifrado AES-256, SSO, auditoría completa de accesos y cumplimiento SOC 2 Type II.',
    },
    {
      icon: 'ti-api',
      title: 'API Rest completa',
      description: 'Construye sobre Nexus con nuestra API documentada y SDKs para Node.js, Python y Ruby.',
    },
  ];
}
