import { Component } from '@angular/core';

@Component({
  selector: 'app-cta',
  standalone: true,
  template: `
    <section class="cta-section">
      <div class="container text-center">
        <span class="section-tag">Empieza hoy</span>
        <h2 class="cta-title">¿Listo para escalar?</h2>
        <p class="section-subtitle mx-auto" style="max-width:460px;margin-bottom:2.5rem">
          Únete a más de 12,000 equipos que ya usan Nexus para crecer más rápido.
        </p>
        <div class="cta-actions">
          <a href="#pricing" class="btn-primary-brand">
            Empezar gratis — sin tarjeta <i class="ti ti-arrow-right"></i>
          </a>
          <a href="#" class="btn-ghost">Solicitar demo</a>
        </div>
        <p class="cta-note">14 días de prueba en plan Pro · Sin compromisos · Cancela cuando quieras</p>
      </div>
    </section>
  `,
  styles: [`
    .cta-section {
      padding: 6rem 0;
      background: linear-gradient(135deg, rgba(79,70,229,0.05), rgba(16,185,129,0.03));
      border-top: 1px solid var(--border);
    }
    .cta-title {
      font-size: clamp(2rem, 4vw, 3.2rem);
      font-weight: 800;
      letter-spacing: -1.5px;
      margin-bottom: 1.2rem;
    }
    .cta-actions {
      display: flex;
      justify-content: center;
      flex-wrap: wrap;
      gap: 1rem;
      margin-bottom: 1.25rem;
    }
    .cta-note {
      font-size: 0.82rem;
      color: var(--muted);
    }
  `],
})
export class CtaComponent {}
