import { Component } from '@angular/core';

@Component({
  selector: 'app-footer',
  standalone: true,
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss'],
})
export class FooterComponent {
  links = {
    producto:  ['Características', 'Integraciones', 'Precios', 'Changelog', 'Roadmap'],
    compania:  ['Acerca de', 'Blog', 'Carreras', 'Prensa', 'Contacto'],
    legal:     ['Privacidad', 'Términos', 'Seguridad', 'GDPR'],
  };

  socials = [
    { icon: 'ti-brand-x',        label: 'Twitter/X' },
    { icon: 'ti-brand-linkedin', label: 'LinkedIn' },
    { icon: 'ti-brand-github',   label: 'GitHub' },
    { icon: 'ti-brand-discord',  label: 'Discord' },
  ];
}
