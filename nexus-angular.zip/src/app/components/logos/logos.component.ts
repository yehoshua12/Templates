import { Component } from '@angular/core';

@Component({
  selector: 'app-logos',
  standalone: true,
  template: `
    <div class="logos-section">
      <div class="container">
        <p class="logos-label">Confiado por equipos en empresas como</p>
        <div class="logos-grid">
          @for (logo of logos; track logo) {
            <span class="logo-item">{{ logo }}</span>
          }
        </div>
      </div>
    </div>
  `,
  styles: [`
    .logos-section {
      padding: 2.5rem 0;
      border-top: 1px solid var(--border);
      border-bottom: 1px solid var(--border);
      background: var(--bg2);
    }
    .logos-label {
      text-align: center;
      font-size: 0.78rem;
      color: var(--muted);
      letter-spacing: 2px;
      text-transform: uppercase;
      margin-bottom: 1.5rem;
    }
    .logos-grid {
      display: flex;
      justify-content: center;
      align-items: center;
      flex-wrap: wrap;
      gap: 2rem 3rem;
    }
    .logo-item {
      font-family: 'Syne', sans-serif;
      font-weight: 700;
      font-size: 1.05rem;
      color: #CBD5E1;
      letter-spacing: -0.5px;
      transition: color 0.2s;
      cursor: default;
      &:hover { color: var(--muted); }
    }
  `],
})
export class LogosComponent {
  logos = ['Starkflow', 'Meridian', 'Orbis Co.', 'VaultHQ', 'Pulsar Inc.', 'Novalith'];
}
