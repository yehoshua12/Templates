import { Component } from '@angular/core';
import { NavbarComponent }       from './components/navbar/navbar.component';
import { HeroComponent }         from './components/hero/hero.component';
import { LogosComponent }        from './components/logos/logos.component';
import { FeaturesComponent }     from './components/features/features.component';
import { HowItWorksComponent }   from './components/how-it-works/how-it-works.component';
import { PricingComponent }      from './components/pricing/pricing.component';
import { TestimonialsComponent } from './components/testimonials/testimonials.component';
import { FaqComponent }          from './components/faq/faq.component';
import { CtaComponent }          from './components/cta/cta.component';
import { FooterComponent }       from './components/footer/footer.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    NavbarComponent,
    HeroComponent,
    LogosComponent,
    FeaturesComponent,
    HowItWorksComponent,
    PricingComponent,
    TestimonialsComponent,
    FaqComponent,
    CtaComponent,
    FooterComponent,
  ],
  template: `
    <app-navbar></app-navbar>
    <main>
      <app-hero></app-hero>
      <app-logos></app-logos>
      <app-features></app-features>
      <app-how-it-works></app-how-it-works>
      <app-pricing></app-pricing>
      <app-testimonials></app-testimonials>
      <app-faq></app-faq>
      <app-cta></app-cta>
    </main>
    <app-footer></app-footer>
  `,
})
export class AppComponent {}
